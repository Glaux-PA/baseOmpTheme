# baseOmpTheme

Custom theme that inherits default templates with bootstrap 5 packages

## Instructions

### Plugin Installation Guide for Omp

You can install this plugin in two ways:

#### 1. Upload via the Omp Web Interface

-   Go to the Dashboard > Website Settings > Plugins.
-   Click on Upload a New Plugin.
-   Select the plugin `.tar.gz` or `.zip` archive and upload it.
-   Once installed, make sure to enable the plugin.

#### 2. Manual Installation

-   Upload or extract the plugin folder into the appropriate directory:
    -   ojs/plugins/generic
    -   Activate plugin from plugin from "Website -> Plugins"
